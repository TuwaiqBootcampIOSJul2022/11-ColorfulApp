

import UIKit

class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {
 

    @IBOutlet weak var tabelView: UITableView!
    
   
    var sand = Color(name: "", uiColor: UIColor.clear)
    
    var colors = [Color(name: "orange"    ,uiColor:UIColor.orange),
                  Color(name: "yellow" ,uiColor:UIColor.yellow),
                  Color(name: "green"  ,uiColor:UIColor.green),
                  Color(name: "white" ,uiColor:UIColor.white),]
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
       
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return colors.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = colors[indexPath.row].name
        cell.backgroundColor = colors[indexPath.row].uiColor
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        sand = colors[indexPath.row]
        
        performSegue(withIdentifier: "changeColor", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "changeColor"
        {
            if let viewVC = segue.destination as? Calor
            {
                viewVC.car = sand
                viewVC.view.backgroundColor = sand.uiColor
            
                
            }
        }
    }

        
   }



