//
//  Color.swift
//  ColorsTabel
//
//  Created by Waad on 23/01/1444 AH.
//

import UIKit


struct Color {

    var name: String
    var uiColor: UIColor
    
}

