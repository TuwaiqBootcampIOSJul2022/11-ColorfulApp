

import UIKit

class Calor: UIViewController {

    var car = Color(name: "", uiColor: UIColor.clear)

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      print(car)
       
    }
    



}
