//
//  ColorShowViewController.swift
//  A11
//
//  Created by KHalidateeq on 23/01/1444 AH.
//

import UIKit

class Color1ViewController: UIViewController {
    var nameSend1:[UIColor] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = nameSend1.first
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
